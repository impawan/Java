
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import com.sun.xml.messaging.saaj.soap.MessageFactoryImpl;
import com.sun.xml.*;

//import com.sun.xml.internal.messaging.saaj.SOAPExceptionImpl;
public class WebService {

    public static void main(String[] args) throws SOAPException, IOException {
        try {
            String endpoint = "https://www.dataaccess.com/webservicesserver/numberconversion.wso";
           
            //System.setProperty("javax.xml.soap.MessageFactory","org.apache.axis.soap.MessageFactoryImpl"); 
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
    
            MimeHeaders mimeHeader = message.getMimeHeaders();
            mimeHeader.addHeader("Host", "www.dataaccess.com");
            mimeHeader.addHeader("Content-Type", "text/xml; charset=utf-8");
            
            mimeHeader.addHeader("SOAPAction","/webservicesserver/numberconversion.wso");

            SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
            envelope.addNamespaceDeclaration("soap", "http://schemas.xmlsoap.org/soap/envelope/");
            envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
            
            SOAPBody body = message.getSOAPBody();
            
            SOAPElement temp = body.addChildElement("NumberToWords", "","http://www.dataaccess.com/webservicesserver/");

            SOAPElement fahr = temp.addChildElement("ubiNum");
            fahr.addTextNode("140");
            
            // SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
           // message.writeTo(System.out);
            SOAPConnection connection = SOAPConnectionFactory.newInstance().createConnection();
            SOAPMessage response = connection.call(message, endpoint);
            connection.close();
            
            //response.writeTo(System.out);
            //String res ="";
            //res = response.toString();
            //System.out.println(res);
            
            
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            response.writeTo(stream);
            String res = new String(stream.toByteArray(), "utf-8") ;
            

        } catch (SOAPException ex) {
            ex.printStackTrace();
        }

    }
}

