import java.io.IOException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

public class Calculator  {

    public static void main(String[] args) throws SOAPException {
        try {
        	//System.setProperty("java.net.useSystemProxies", "true");
            String endpoint = "http://dneonline.com/calculator.asmx";
            
            
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();

          
            MimeHeaders mimeHeader = message.getMimeHeaders();
            mimeHeader.addHeader("Host", "dneonline.com");
            mimeHeader.addHeader("Content-Type", "text/xml; charset=utf-8");

            mimeHeader.addHeader("SOAPAction", "http://tempuri.org/Add");

            SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
            envelope.addNamespaceDeclaration("soap", "http://schemas.xmlsoap.org/soap/envelope/");
            envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
            
            SOAPBody body = message.getSOAPBody();
            
            SOAPElement temp = body.addChildElement("Add", "","http://tempuri.org/");

            SOAPElement intA = temp.addChildElement("intA");
            intA.addTextNode("2");
            
            SOAPElement intB = temp.addChildElement("intB");
            intB.addTextNode("3");

            
            message.writeTo(System.out);

            SOAPConnection connection = SOAPConnectionFactory.newInstance().createConnection();
            SOAPMessage response = connection.call(message, endpoint);
            connection.close();

            System.out.println("");
            System.out.println("---------------");
            response.writeTo(System.out);

        } catch (SOAPException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
    
    
    
   /* private SOAPMessage getSoapMessageFromString(String xml) throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(), new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));
        return message; 
    }*/
    
    
}